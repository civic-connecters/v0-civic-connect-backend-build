import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Camera, 
  MapPin, 
  Brain, 
  Users, 
  Clock, 
  Eye, 
  Smartphone, 
  Award,
  BarChart3
} from "lucide-react";
import featuresImage from "@/assets/civic-features.jpg";

const Features = () => {
  const features = [
    {
      icon: Camera,
      title: "Geo-tagged Reporting",
      description: "Snap photos and videos with automatic location tagging for precise issue identification.",
      color: "text-primary",
      bgColor: "bg-primary/10"
    },
    {
      icon: Brain,
      title: "AI-Powered Categorization",
      description: "Intelligent routing to the right department using advanced NLP and machine learning.",
      color: "text-accent",
      bgColor: "bg-accent/10"
    },
    {
      icon: Clock,
      title: "Real-time Tracking",
      description: "Track your issue status with unique ID and live updates throughout the resolution process.",
      color: "text-secondary",
      bgColor: "bg-secondary/10"
    },
    {
      icon: Users,
      title: "Crowdsourced Validation",
      description: "Community upvoting and duplicate detection to prioritize and streamline issues.",
      color: "text-primary",
      bgColor: "bg-primary/10"
    },
    {
      icon: Eye,
      title: "Complete Transparency",
      description: "Public visibility of all issues and resolutions for government accountability.",
      color: "text-accent",
      bgColor: "bg-accent/10"
    },
    {
      icon: Smartphone,
      title: "Mobile-First Design",
      description: "Optimized for smartphones with offline capability and cross-platform support.",
      color: "text-secondary",
      bgColor: "bg-secondary/10"
    }
  ];

  return (
    <section id="features" className="py-24 bg-gradient-subtle">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 px-4 py-2">
            <Award className="h-4 w-4 mr-2" />
            Smart Features
          </Badge>
          <h2 className="section-title">
            Modern Technology for
            <br />
            <span className="text-primary">Civic Engagement</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Combining cutting-edge technology with citizen-centric design to create 
            the most effective civic issue reporting platform.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Features List */}
          <div className="space-y-6">
            {features.map((feature, index) => (
              <Card key={index} className="feature-card group">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className={`p-3 rounded-lg ${feature.bgColor} group-hover:scale-110 transition-transform duration-300`}>
                      <feature.icon className={`h-6 w-6 ${feature.color}`} />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-foreground mb-2">
                        {feature.title}
                      </h3>
                      <p className="text-muted-foreground leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Features Image */}
          <div className="relative">
            <div className="rounded-2xl overflow-hidden shadow-floating">
              <img
                src={featuresImage}
                alt="Civic Connect features visualization"
                className="w-full h-auto object-cover"
              />
            </div>
            
            {/* Floating Stats Cards */}
            <div className="absolute -top-6 -right-6 bg-card border border-border rounded-xl p-4 shadow-lg animate-float">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <BarChart3 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-foreground">98%</div>
                  <div className="text-sm text-muted-foreground">Resolution Rate</div>
                </div>
              </div>
            </div>

            <div className="absolute -bottom-6 -left-6 bg-card border border-border rounded-xl p-4 shadow-lg animate-float" style={{ animationDelay: "1s" }}>
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-secondary/10 rounded-lg">
                  <Clock className="h-5 w-5 text-secondary" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-foreground">2.3 days</div>
                  <div className="text-sm text-muted-foreground">Avg Resolution</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center">
          <p className="text-muted-foreground mb-6">
            Ready to experience the future of civic engagement?
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="btn-civic">
              Start Reporting Issues
            </button>
            <button className="px-6 py-3 border border-border rounded-lg text-foreground hover:bg-muted/50 transition-colors">
              View Demo
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;