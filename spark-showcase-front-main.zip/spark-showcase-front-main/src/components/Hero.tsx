import { Button } from "@/components/ui/button";
import { Camera, MapPin, Clock, Users } from "lucide-react";
import heroImage from "@/assets/civic-hero.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Citizens engaging with civic technology"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/70 to-background/90"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-8 animate-fade-in">
            <MapPin className="h-4 w-4 mr-2" />
            Powered by Smart City Technology
          </div>

          {/* Main Heading */}
          <h1 className="hero-text mb-6 animate-slide-up">
            Report, Track &amp; Resolve
            <br />
            <span className="text-accent">Civic Issues</span>
          </h1>

          {/* Subheading */}
          <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed animate-fade-in">
            Modern civic engagement platform with geo-tagged reporting, AI-driven categorization, 
            and transparent tracking for smarter, more responsive cities.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16 animate-scale-in">
            <Button size="lg" className="btn-civic text-lg px-8 py-4 h-auto">
              <Camera className="h-5 w-5 mr-2" />
              Report an Issue
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-4 h-auto border-2 hover:bg-primary/5">
              <MapPin className="h-5 w-5 mr-2" />
              Track Issues
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-3xl mx-auto animate-fade-in">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">24/7</div>
              <div className="text-sm text-muted-foreground">Issue Tracking</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-accent mb-2">AI</div>
              <div className="text-sm text-muted-foreground">Smart Routing</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-secondary mb-2">Real-time</div>
              <div className="text-sm text-muted-foreground">Updates</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">100%</div>
              <div className="text-sm text-muted-foreground">Transparent</div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Elements */}
      <div className="absolute top-20 left-10 hidden lg:block animate-float">
        <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
          <Clock className="h-6 w-6 text-primary" />
        </div>
      </div>
      <div className="absolute bottom-20 right-10 hidden lg:block animate-float" style={{ animationDelay: "1s" }}>
        <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
          <Users className="h-6 w-6 text-accent" />
        </div>
      </div>
    </section>
  );
};

export default Hero;