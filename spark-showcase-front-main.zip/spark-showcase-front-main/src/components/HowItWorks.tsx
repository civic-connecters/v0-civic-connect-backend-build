import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Camera, 
  Send, 
  Cog, 
  CheckCircle, 
  ArrowRight,
  MapPin,
  Brain,
  Users
} from "lucide-react";

const HowItWorks = () => {
  const steps = [
    {
      step: "01",
      title: "Report Issue",
      description: "Take a photo or video of the civic issue. Our app automatically geo-tags your location and creates a unique tracking ID.",
      icon: Camera,
      color: "text-primary",
      bgColor: "bg-primary/10",
      features: ["Photo/Video capture", "Auto geo-tagging", "Unique ID generation"]
    },
    {
      step: "02", 
      title: "AI Processing",
      description: "Our AI system categorizes your issue and routes it to the appropriate government department for faster resolution.",
      icon: Brain,
      color: "text-accent",
      bgColor: "bg-accent/10",
      features: ["Smart categorization", "Auto-routing", "Department matching"]
    },
    {
      step: "03",
      title: "Community Validation",
      description: "Other citizens can upvote your issue and mark duplicates, helping prioritize the most urgent problems.",
      icon: Users,
      color: "text-secondary",
      bgColor: "bg-secondary/10", 
      features: ["Community upvoting", "Duplicate detection", "Priority ranking"]
    },
    {
      step: "04",
      title: "Track & Resolve",
      description: "Monitor real-time progress updates and see the resolution through our transparent tracking system.",
      icon: CheckCircle,
      color: "text-primary",
      bgColor: "bg-primary/10",
      features: ["Real-time updates", "Status tracking", "Resolution confirmation"]
    }
  ];

  return (
    <section id="how-it-works" className="py-24 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 px-4 py-2">
            <Cog className="h-4 w-4 mr-2" />
            Process
          </Badge>
          <h2 className="section-title">
            How <span className="text-primary">Civic Connect</span>
            <br />
            Works For You
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Simple, efficient, and transparent. Our four-step process ensures 
            your civic issues get the attention they deserve.
          </p>
        </div>

        {/* Steps */}
        <div className="max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {/* Step Card */}
              <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
                {/* Content Side */}
                <div className={`${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                  <div className="flex items-center mb-6">
                    <div className={`p-4 rounded-xl ${step.bgColor} mr-4`}>
                      <step.icon className={`h-8 w-8 ${step.color}`} />
                    </div>
                    <div className="text-6xl font-bold text-muted/20">
                      {step.step}
                    </div>
                  </div>
                  
                  <h3 className="text-3xl font-bold text-foreground mb-4">
                    {step.title}
                  </h3>
                  
                  <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                    {step.description}
                  </p>

                  {/* Features List */}
                  <ul className="space-y-3">
                    {step.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-foreground">
                        <CheckCircle className="h-5 w-5 text-secondary mr-3 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Visual Side */}
                <div className={`${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                  <Card className="card-civic">
                    <CardContent className="p-8">
                      <div className="text-center">
                        <div className={`inline-flex p-6 rounded-full ${step.bgColor} mb-6`}>
                          <step.icon className={`h-12 w-12 ${step.color}`} />
                        </div>
                        <h4 className="text-xl font-semibold mb-4">Step {step.step}</h4>
                        <div className="space-y-4">
                          {/* Mock UI elements based on step */}
                          {index === 0 && (
                            <div className="bg-muted/50 rounded-lg p-4">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-sm text-muted-foreground">📷 Photo captured</span>
                                <MapPin className="h-4 w-4 text-primary" />
                              </div>
                              <div className="text-xs text-muted-foreground">Location: Auto-detected</div>
                              <div className="text-xs text-muted-foreground">ID: CC-2024-001</div>
                            </div>
                          )}
                          {index === 1 && (
                            <div className="bg-muted/50 rounded-lg p-4">
                              <div className="text-sm text-foreground mb-2">🤖 AI Analysis Complete</div>
                              <div className="text-xs text-muted-foreground">Category: Road Maintenance</div>
                              <div className="text-xs text-muted-foreground">Routed to: Public Works Dept.</div>
                            </div>
                          )}
                          {index === 2 && (
                            <div className="bg-muted/50 rounded-lg p-4">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-sm text-foreground">👥 Community Support</span>
                                <span className="text-xs text-secondary">↑ 24 votes</span>
                              </div>
                              <div className="text-xs text-muted-foreground">Priority: High</div>
                            </div>
                          )}
                          {index === 3 && (
                            <div className="bg-muted/50 rounded-lg p-4">
                              <div className="space-y-2">
                                <div className="flex justify-between text-xs">
                                  <span>Reported</span>
                                  <span className="text-secondary">✓</span>
                                </div>
                                <div className="flex justify-between text-xs">
                                  <span>In Progress</span>
                                  <span className="text-secondary">✓</span>
                                </div>
                                <div className="flex justify-between text-xs">
                                  <span>Resolved</span>
                                  <span className="text-primary">✓</span>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Arrow Connector (except for last step) */}
              {index < steps.length - 1 && (
                <div className="flex justify-center mb-16">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-muted">
                    <ArrowRight className="h-6 w-6 text-muted-foreground" />
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <h3 className="text-2xl font-bold text-foreground mb-4">
            Ready to make a difference in your community?
          </h3>
          <p className="text-muted-foreground mb-8">
            Join thousands of citizens already using Civic Connect to improve their cities.
          </p>
          <button className="btn-civic">
            Get Started Today
          </button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;